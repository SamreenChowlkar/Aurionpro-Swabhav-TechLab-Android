package com.example.samreen


data class EducationItems(
    val degree: String,
    val institution: String,
    val duration: String,
    val score: String
)