package com.example.newslist

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: NewsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.newsRecyclerView)
        adapter = NewsAdapter()


        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        recyclerView.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )

        val moreNews = listOf(
            NewsItem(
                "1",
                "Space agency announces new mission to Mars",
                "A new era in interplanetary exploration begins...",
                "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=200&q=80",
                "Aug 12, 2025",
                "The space agency has officially announced its next mission to Mars, aiming to explore the planet's surface and search for signs of life. This marks a significant milestone in interplanetary exploration, with advanced robotics and AI systems leading the charge. The mission will deploy a new rover equipped with cutting-edge sensors and autonomous navigation capabilities. Scientists hope to gather data on Martian geology and climate, which could inform future human missions. The launch is scheduled for late next year, with international collaboration playing a key role in its success."
            ),
            NewsItem(
                "2",
                "Local tech startup raises seed funding",
                "Investors back promising ML startup focused on healthcare...",
                "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=200&q=80",
                "Aug 11, 2025",
                "A promising local tech startup focused on machine learning applications in healthcare has successfully raised seed funding from a group of angel investors. The startup aims to revolutionize diagnostic tools by leveraging AI to detect diseases at early stages. With the new funding, the company plans to expand its team, accelerate product development, and initiate clinical trials. The founders expressed gratitude for the support and emphasized their commitment to improving patient outcomes through technology."
            ),
            NewsItem(
                "3",
                "How to build a RecyclerView in 5 minutes",
                "Step by step guide with example code",
                "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=200&q=80",
                "Aug 10, 2025",
                "Building a RecyclerView in Android can be quick and efficient with the right approach. This guide walks developers through the essential steps: setting up the RecyclerView in XML, creating an adapter and view holder, and binding data to the views. With reusable components and proper layout management, RecyclerView offers a flexible way to display lists and grids. The tutorial includes code snippets and best practices to help developers implement RecyclerView in under five minutes."
            ),
            NewsItem(
                "4",
                "Global markets rally after positive economic data",
                "Stocks surged worldwide following better-than-expected reports...",
                "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=200&q=80",
                "Aug 9, 2025",
                "Global financial markets experienced a significant rally following the release of positive economic data. Reports indicated stronger-than-expected growth in manufacturing and consumer spending, boosting investor confidence. Major stock indices rose across the board, with technology and energy sectors leading the gains. Analysts suggest that the data may prompt central banks to maintain supportive monetary policies, further fueling market optimism."
            ),
            NewsItem(
                "5",
                "New electric vehicle model launched by major automaker",
                "The latest EV boasts longer range and faster charging times...",
                "https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=200&q=80",
                "Aug 9, 2025",
                "A leading automaker has unveiled its latest electric vehicle model, featuring an extended driving range and faster charging capabilities. The new EV boasts a sleek design, advanced safety features, and a user-friendly infotainment system. Industry experts praise the vehicle for its innovation and potential to accelerate the transition to sustainable transportation. The automaker plans to begin deliveries early next year, with pre-orders already exceeding expectations."
            ),
            NewsItem(
                "6",
                "Scientists discover potential cure for rare disease",
                "Breakthrough treatment shows promise in early clinical trials...",
                "https://images.unsplash.com/photo-1518773553398-650c184e0bb3?auto=format&fit=crop&w=200&q=80",
                "Aug 8, 2025",
                "In a groundbreaking development, scientists have discovered a potential cure for a rare genetic disease affecting thousands worldwide. The treatment, based on gene therapy, has shown promising results in early clinical trials, significantly improving patient symptoms. Researchers are optimistic about the therapy's long-term efficacy and are preparing for larger-scale studies. The discovery represents a major step forward in personalized medicine and offers hope to affected families."
            ),
            NewsItem(
                "7",
                "Local community garden initiative blossoms",
                "Residents come together to promote sustainable urban farming...",
                "https://images.unsplash.com/photo-1464037866556-6812c9d1c72e?auto=format&fit=crop&w=200&q=80",
                "Aug 7, 2025",
                "A local community garden initiative has gained momentum, bringing residents together to promote sustainable urban farming. Volunteers have transformed vacant lots into thriving gardens, growing fresh produce and fostering a sense of community. The project also includes educational workshops on composting, nutrition, and gardening techniques. Organizers hope to expand the initiative to other neighborhoods and encourage healthy living through hands-on engagement."
            ),
            NewsItem(
                "8",
                "Tech giant announces new AI research center",
                "The center will focus on advancing machine learning capabilities...",
                "https://images.unsplash.com/photo-1518773553398-650c184e0bb3?auto=format&fit=crop&w=200&q=80",
                "Aug 7, 2025",
                "A major technology company has announced the launch of a new AI research center dedicated to advancing machine learning and artificial intelligence. The center will focus on developing ethical AI systems, improving natural language processing, and exploring new applications in robotics and automation. The initiative aims to collaborate with academic institutions and industry partners to drive innovation and address global challenges through AI."
            ),
            NewsItem(
                "9",
                "Major sports event postponed due to weather",
                "Officials reschedule the championship game amid storm warnings...",
                "https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=200&q=80",
                "Aug 6, 2025",
                "Organizers of a major sports championship have postponed the event due to severe weather conditions. Storm warnings and safety concerns prompted the decision, with officials prioritizing the well-being of athletes and spectators. The event will be rescheduled for a later date, with ticket holders advised to retain their passes. Fans expressed understanding and support for the precautionary measures taken."
            ),
            NewsItem(
                "10",
                "How to boost productivity working from home",
                "Tips and tricks to stay focused and efficient in a remote setup...",
                "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=200&q=80",
                "Aug 6, 2025",
                "Working from home presents unique challenges and opportunities for productivity. Experts recommend setting a dedicated workspace, maintaining a consistent schedule, and minimizing distractions. Incorporating regular breaks, exercise, and clear communication with colleagues can enhance focus and efficiency. This guide offers practical tips and tools to help remote workers stay motivated and achieve their goals."
            ),
            NewsItem(
                "11",
                "New cafe opens downtown with unique menu",
                "Foodies rejoice as a fusion cuisine spot debuts in the city...",
                "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=200&q=80",
                "Aug 5, 2025",
                "A new cafe has opened in the downtown area, offering a unique fusion menu that blends international flavors with local ingredients. The cozy ambiance and creative dishes have attracted food enthusiasts and curious diners alike. The cafe also features locally roasted coffee and artisanal desserts. Owners hope to create a welcoming space for community gatherings and culinary exploration."
            ),
            NewsItem(
                "12",
                "Advancements in renewable energy technology",
                "Innovations could lead to cheaper and more efficient solar panels...",
                "https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=200&q=80",
                "Aug 4, 2025",
                "Recent advancements in renewable energy technology are paving the way for more efficient and affordable solar panels. Researchers have developed new materials that increase energy conversion rates and reduce production costs. These innovations could accelerate the adoption of clean energy solutions and contribute to global sustainability efforts. Industry leaders are optimistic about the future of renewable energy and its role in combating climate change."
            ),
            NewsItem(
                "13",
                "Upcoming movie trailer breaks records online",
                "Fans eagerly await release after teaser goes viral...",
                "https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=200&q=80",
                "Aug 3, 2025",
                "The trailer for an upcoming blockbuster movie has shattered online viewership records, generating excitement among fans worldwide. Featuring stunning visuals and a star-studded cast, the teaser has gone viral across social media platforms. The film's producers credit the marketing campaign and fan engagement for the overwhelming response. Anticipation continues to build ahead of the movie's release later this year."
            )
        )


        adapter.submitList(moreNews)
    }
}
