package com.example.newslist

import java.io.Serializable

data class NewsItem(
    val id: String,
    val title: String,
    val summary: String,
    val imageUrl: String?,
    val publishedAt: String,
    val fullContent: String
) : Serializable

