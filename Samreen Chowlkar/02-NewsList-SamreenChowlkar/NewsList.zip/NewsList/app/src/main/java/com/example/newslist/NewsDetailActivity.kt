package com.example.newslist

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class NewsDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_detail)

        val newsItem = intent.getSerializableExtra("newsItem") as? NewsItem
        val backButton: ImageView = findViewById(R.id.backButton)
        val titleTv: TextView = findViewById(R.id.detailTitle)
        val dateTv: TextView = findViewById(R.id.detailDate)
        val imageIv: ImageView = findViewById(R.id.detailImage)
        val contentTv: TextView = findViewById(R.id.detailContent)
        backButton.setOnClickListener {
            onBackPressed()
        }
        newsItem?.let {
            titleTv.text = it.title
            dateTv.text = it.publishedAt
            contentTv.text = newsItem.fullContent

            Glide.with(this)
                .load(it.imageUrl)
                .centerCrop()
                .into(imageIv)
        }
    }
}
