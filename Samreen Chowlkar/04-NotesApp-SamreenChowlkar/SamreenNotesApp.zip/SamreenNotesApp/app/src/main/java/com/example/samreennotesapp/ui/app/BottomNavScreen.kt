package com.example.samreennotesapp.ui.app

sealed class BottomNavScreen(val route: String, val label: String) {
    object Notes : BottomNavScreen("notes", "Notes")
    object Todos : BottomNavScreen("todos", "Todos")
}
