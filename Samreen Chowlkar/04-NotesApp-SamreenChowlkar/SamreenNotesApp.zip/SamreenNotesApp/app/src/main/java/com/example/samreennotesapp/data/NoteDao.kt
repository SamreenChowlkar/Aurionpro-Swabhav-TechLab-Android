package com.example.samreennotesapp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {

    // Observe all notes sorted by updated time
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<Note>>

    // Search notes by title or content
    @Query("SELECT * FROM notes WHERE title LIKE '%' || :q || '%' OR content LIKE '%' || :q || '%' ORDER BY updatedAt DESC")
    fun search(q: String): Flow<List<Note>>

    // Observe a single note by id (Flow)
    @Query("SELECT * FROM notes WHERE id = :noteId LIMIT 1")
    fun observeById(noteId: Long): Flow<Note?>

    // Fetch single note once (suspend)
    @Query("SELECT * FROM notes WHERE id = :noteId LIMIT 1")
    suspend fun getById(noteId: Long): Note?

    // Insert or update a note
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: Note): Long

    // Delete a note
    @Delete
    suspend fun delete(note: Note)
}
