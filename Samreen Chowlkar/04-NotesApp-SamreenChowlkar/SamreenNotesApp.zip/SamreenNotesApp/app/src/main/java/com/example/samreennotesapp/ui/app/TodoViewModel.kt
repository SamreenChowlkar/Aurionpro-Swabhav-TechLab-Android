package com.example.samreennotesapp.ui.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.samreennotesapp.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TodoViewModel(private val repo: TodoRepository) : ViewModel() {
    val todos: StateFlow<List<Todo>> = repo.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(text: String) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        repo.upsert(Todo(text = text, createdAt = now, updatedAt = now))
    }

    fun toggle(todo: Todo) = viewModelScope.launch {
        repo.upsert(todo.copy(isDone = !todo.isDone, updatedAt = System.currentTimeMillis()))
    }

    fun delete(todo: Todo) = viewModelScope.launch {
        repo.delete(todo)
    }
}
