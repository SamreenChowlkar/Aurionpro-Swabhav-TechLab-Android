package com.example.samreennotesapp.ui.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.samreennotesapp.data.Todo

@Composable
fun TodoScreen(vm: TodoViewModel) {
    val todos by vm.todos.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Input row
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Add a task") }
            )
            Button(
                onClick = {
                    if (text.isNotBlank()) {
                        vm.add(text.trim())
                        text = ""
                    }
                }
            ) {
                Text("Add")
            }
        }

        // Todo list
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(todos, key = { it.id }) { todo ->
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Checkbox(
                                checked = todo.isDone,
                                onCheckedChange = { vm.toggle(todo) }
                            )
                            Text(todo.text)
                        }
                        TextButton(onClick = { vm.delete(todo) }) {
                            Text("Delete")
                        }
                    }
                }
            }
        }
    }
}
