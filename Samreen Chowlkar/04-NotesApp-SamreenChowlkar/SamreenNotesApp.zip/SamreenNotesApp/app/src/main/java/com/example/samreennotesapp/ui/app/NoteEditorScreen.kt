package com.example.samreennotesapp.ui.app

import NoteViewModel
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import com.example.samreennotesapp.data.Note
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun NoteEditorScreen(
    noteId: Long = 0L,                 // Pass noteId from NavHost
    viewModel: NoteViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
    onDone: () -> Unit
) {
    var title by remember { mutableStateOf(TextFieldValue("")) }
    var content by remember { mutableStateOf(TextFieldValue("")) }
    var createdAt by remember { mutableStateOf<Long?>(null) }
    var updatedAt by remember { mutableStateOf<Long?>(null) }

    val scope = rememberCoroutineScope()

    // Load note once for editing
    LaunchedEffect(noteId) {
        if (noteId != 0L) {
            val note = viewModel.getNoteByIdOnce(noteId)
            note?.let {
                title = TextFieldValue(it.title)
                content = TextFieldValue(it.content)
                createdAt = it.createdAt
                updatedAt = it.updatedAt
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (noteId == 0L) "New Note" else "Edit Note") },
                actions = {
                    TextButton(onClick = {
                        val now = System.currentTimeMillis()
                        val note = Note(
                            id = noteId,
                            title = title.text.trim(),
                            content = content.text.trim(),
                            createdAt = createdAt ?: now,
                            updatedAt = now
                        )
                        scope.launch { viewModel.saveNote(note) }
                        onDone()
                    }) {
                        Text("Save")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("Note") },
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            )

            val editedText = (updatedAt ?: System.currentTimeMillis()).formatAsDateTime()
            Text("Last edited: $editedText", style = MaterialTheme.typography.labelMedium)
        }
    }
}

// ----------------- Helper -----------------

@RequiresApi(Build.VERSION_CODES.O)
fun Long.formatAsDateTime(): String {
    val formatter = DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a")
    return Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).format(formatter)
}
