package com.example.samreennotesapp

import NoteViewModel
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import com.example.samreennotesapp.data.AppDatabase
import com.example.samreennotesapp.data.NoteRepository
import com.example.samreennotesapp.data.TodoRepository
import com.example.samreennotesapp.ui.app.MainAppScreen
import com.example.samreennotesapp.ui.app.TodoViewModel
import com.example.samreennotesapp.ui.theme.SamreenNotesAppTheme

class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SamreenNotesAppTheme {
                val database = AppDatabase.get(this)
                val noteRepo = NoteRepository(database.noteDao())
                val noteVM = NoteViewModel(noteRepo)
                val todoVM = TodoViewModel(TodoRepository(database.todoDao()))

                // Launch the main screen with Bottom Navigation
                MainAppScreen(noteVM, todoVM)
            }
        }
    }
}
