package com.example.samreennotesapp.data

import kotlinx.coroutines.flow.Flow

class NoteRepository(private val dao: NoteDao) {

    fun observeAll(): Flow<List<Note>> = dao.observeAll()

    fun search(q: String): Flow<List<Note>> =
        if (q.isBlank()) observeAll() else dao.search(q)

    // Fetch single note once
    suspend fun getNoteById(id: Long): Note? = dao.getById(id)

    // Observe single note
    fun observeNoteById(id: Long): Flow<Note?> = dao.observeById(id)

    suspend fun upsert(note: Note) = dao.upsert(note)

    suspend fun delete(note: Note) = dao.delete(note)
}
