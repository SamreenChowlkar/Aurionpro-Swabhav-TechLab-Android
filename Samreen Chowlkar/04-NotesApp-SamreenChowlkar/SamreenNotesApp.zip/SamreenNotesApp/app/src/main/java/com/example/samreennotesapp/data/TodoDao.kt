package com.example.samreennotesapp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TodoDao {

    // Observe all todos sorted by updated time
    @Query("SELECT * FROM todos ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<Todo>>

    // Insert or update
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(todo: Todo): Long

    // Delete
    @Delete
    suspend fun delete(todo: Todo)
}
