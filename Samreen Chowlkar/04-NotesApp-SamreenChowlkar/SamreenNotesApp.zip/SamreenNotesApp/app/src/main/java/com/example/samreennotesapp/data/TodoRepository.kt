package com.example.samreennotesapp.data

import kotlinx.coroutines.flow.Flow

class TodoRepository(private val dao: TodoDao) {

    fun observeAll(): Flow<List<Todo>> = dao.observeAll()

    suspend fun upsert(todo: Todo) = dao.upsert(todo)

    suspend fun delete(todo: Todo) = dao.delete(todo)
}
