import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.samreennotesapp.data.Note
import com.example.samreennotesapp.data.NoteRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class NoteViewModel(private val repo: NoteRepository) : ViewModel() {

    // Holds the current search query
    private val _searchQuery = MutableStateFlow("")

    // Expose notes as a StateFlow that updates automatically based on search query
    val notes: StateFlow<List<Note>> = _searchQuery
        .flatMapLatest { query ->
            repo.search(query)
        }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Update the search query
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Fetch a single note once (suspend)
    suspend fun getNoteByIdOnce(id: Long): Note? = runCatching {
        repo.getNoteById(id)
    }.getOrNull()

    // Save or update a note
    fun saveNote(note: Note) {
        viewModelScope.launch { repo.upsert(note) }
    }

    // Delete a note
    fun deleteNote(note: Note) {
        viewModelScope.launch { repo.delete(note) }
    }
}
