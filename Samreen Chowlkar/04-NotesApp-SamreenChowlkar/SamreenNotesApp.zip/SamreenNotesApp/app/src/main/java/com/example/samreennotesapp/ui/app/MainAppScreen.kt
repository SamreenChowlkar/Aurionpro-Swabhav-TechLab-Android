package com.example.samreennotesapp.ui.app

import NoteViewModel
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import androidx.navigation.NavHostController
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.BlendMode.Companion.Screen
import androidx.navigation.NavType
import androidx.navigation.navArgument

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun MainAppScreen(noteViewModel: NoteViewModel, todoViewModel: TodoViewModel) {
    val navController = rememberNavController()
    val bottomItems = listOf(BottomNavScreen.Notes, BottomNavScreen.Todos)

    Scaffold(
        bottomBar = {
            NavigationBar {
                val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
                bottomItems.forEach { screen ->
                    NavigationBarItem(
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                launchSingleTop = true
                                restoreState = true
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                            }
                        },
                        label = { Text(screen.label) },
                        icon = { /* Optional icon */ }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = BottomNavScreen.Notes.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(BottomNavScreen.Notes.route) {
                NotesScreen(
                    viewModel = noteViewModel,
                    navController = navController,
                    onAddNote = { navController.navigate("editNote/0") },
                    onNoteClick = { id -> navController.navigate("editNote/$id") }
                )
            }
            composable(BottomNavScreen.Todos.route) {
                TodoScreen(vm = todoViewModel)
            }
            composable(
                route = "editNote/{noteId}",
                arguments = listOf(navArgument("noteId") { type = NavType.LongType })
            ) { backStackEntry ->
                val noteId = backStackEntry.arguments?.getLong("noteId") ?: 0L
                NoteEditorScreen(
                    noteId = noteId,
                    viewModel = noteViewModel,
                    onDone = { navController.popBackStack() }
                )
            }
        }

    }
}
