package com.example.weatherappapi.data.remote.model

data class GeocodingResponse(
    val results: List<GeoLocation>?
)

data class GeoLocation(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val country: String?,
    val admin1: String?
)