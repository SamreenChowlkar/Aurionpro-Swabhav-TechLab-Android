package com.example.weatherappapi.data.remote.api

import com.example.weatherappapi.data.remote.model.GeocodingResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface GeocodingApi {
    // https://geocoding-api.open-meteo.com/v1/search?name=Mumbai&count=1&language=en&format=json
    @GET("v1/search")
    suspend fun searchCity(
        @Query("name") name: String,
        @Query("count") count: Int = 1,
        @Query("language") language: String = "en",
        @Query("format") format: String = "json"
    ): GeocodingResponse
}