package com.example.weatherappapi.data

import com.example.weatherappapi.data.remote.api.ForecastApi
import com.example.weatherappapi.data.remote.api.GeocodingApi
import com.example.weatherappapi.data.remote.model.ForecastResponse
import com.example.weatherappapi.data.remote.model.GeoLocation
import javax.inject.Inject

data class WeatherBundle(
    val location: GeoLocation,
    val forecast: ForecastResponse
)

class WeatherRepository @Inject constructor(
    private val geo: GeocodingApi,
    private val forecastApi: ForecastApi
) {
    suspend fun getWeatherForCity(city: String): Result<WeatherBundle> = runCatching {
        val geoResp = geo.searchCity(city, count = 1)
        val loc = geoResp.results?.firstOrNull()
            ?: error("City not found")

        val forecast = forecastApi.getForecast(
            lat = loc.latitude,
            lon = loc.longitude
        )

        WeatherBundle(location = loc, forecast = forecast)
    }
}
