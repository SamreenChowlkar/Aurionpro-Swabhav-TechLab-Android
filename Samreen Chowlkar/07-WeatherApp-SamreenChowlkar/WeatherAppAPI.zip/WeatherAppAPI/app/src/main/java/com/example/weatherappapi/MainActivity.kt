package com.example.weatherappapi

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.weatherappapi.ui.WeatherUiState
import com.example.weatherappapi.ui.WeatherViewModel
import com.example.weatherappapi.ui.weatherCodeToIcon
import com.example.weatherappapi.ui.weatherCodeToText
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.*
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlinx.coroutines.delay
import java.time.Instant

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WeatherAppScreen() }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherAppScreen(viewModel: WeatherViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    var text by remember { mutableStateOf(TextFieldValue("")) }
    val isDaytime = remember { mutableStateOf(true) }
    var time by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        text = TextFieldValue("Mumbai")
        viewModel.city.value = "Mumbai"
        viewModel.fetch()
    }

    // LaunchedEffect to handle timezone and time updates
    LaunchedEffect(state) {
        val timezone = (state as? WeatherUiState.Success)?.data?.forecast?.timezone
        if (timezone != null) {
            val timezoneId = try {
                ZoneId.of(timezone)
            } catch (e: Exception) {
                ZoneId.systemDefault()
            }
            while(true) {
                val now = ZonedDateTime.now(timezoneId)
                val hour = now.hour
                isDaytime.value = hour in 6..18
                val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
                time = formatter.format(Date.from(now.toInstant()))
                delay(60 * 1000L) // Update every minute
            }
        }
    }

    val dayGradientColors = listOf(Color(0xFFFFFFFF),Color(0xFFFDF6BB), Color(0xFFFFCC80),Color(0xFFF9A825))
    val nightGradientColors = listOf( Color(0xFF303F9F), Color(0xFF1A237E),Color(0xFF000000))

    val textColor = if (isDaytime.value) Color.Black else Color.White
    val textAlphaColor = if (isDaytime.value) Color.Black.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.7f)
    val boxBackgroundColor = if (isDaytime.value) Color.White.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.1f)


    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = if (isDaytime.value) dayGradientColors else nightGradientColors
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Title


            // Date and Time Section at the top
            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = SimpleDateFormat("EEEE", Locale.getDefault()).format(Date()).uppercase(),
                        style = MaterialTheme.typography.titleLarge,
                        color = textColor
                    )
                    Text(
                        text = SimpleDateFormat("dd MMMM", Locale.getDefault()).format(Date()),
                        style = MaterialTheme.typography.titleSmall,
                        color = textColor.copy(alpha = 0.8f)
                    )
                }

                Text(
                    text = time,
                    style = MaterialTheme.typography.titleLarge,
                    color = textColor,
                    modifier = Modifier.align(Alignment.CenterVertically)
                )
            }
            Spacer(Modifier.height(24.dp))

            Text(
                "MyRadar",
                style = MaterialTheme.typography.headlineSmall,
                color = textColor
            )
            Spacer(Modifier.height(24.dp))
            // Input and Button Section
            OutlinedTextField(
                value = text,
                onValueChange = {
                    text = it
                    viewModel.city.value = it.text
                },
                label = { Text("Enter city", color = textAlphaColor) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    cursorColor = textColor,
                    focusedBorderColor = textColor,
                    unfocusedBorderColor = textColor.copy(alpha = 0.5f),
                    focusedLabelColor = textColor,
                    unfocusedLabelColor = textAlphaColor,
                    focusedContainerColor = textColor.copy(alpha = 0.1f),
                    unfocusedContainerColor = textColor.copy(alpha = 0.1f),
                    focusedTextColor = textColor,
                    unfocusedTextColor = textColor
                ),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { viewModel.fetch() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(12.dp)),
                colors = ButtonDefaults.buttonColors(containerColor = textColor.copy(alpha = 0.2f)),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
            ) {
                Text("Get Weather", color = textColor, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(32.dp))

            // Weather Content
            when (state) {
                WeatherUiState.Idle -> Text("Type a city and tap Get Weather.", color = textColor)
                WeatherUiState.Loading -> CircularProgressIndicator(color = textColor)
                is WeatherUiState.Error -> Text((state as WeatherUiState.Error).message, color = textColor)
                is WeatherUiState.Success -> {
                    WeatherContent(state as WeatherUiState.Success, isDaytime)
                }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.O)
@Composable
private fun WeatherContent(success: WeatherUiState.Success, isDaytimeState: MutableState<Boolean>) {
    val bundle = success.data
    val loc = bundle.location
    val current = bundle.forecast.current
    val daily = bundle.forecast.daily

    val textColor = if (isDaytimeState.value) Color.Black else Color.White
    val textAlphaColor = if (isDaytimeState.value) Color.Black.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.8f)
    val boxBackgroundColor = if (isDaytimeState.value) Color.White.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 16.dp)
    ) {
        Text(
            "${loc.name}, ${loc.country}".trim().trimEnd(','),
            style = MaterialTheme.typography.headlineMedium,
            color = textColor
        )
        Spacer(Modifier.height(24.dp))

        val weatherIconRes = weatherCodeToIcon(current?.weather_code, isDaytimeState.value)
        Image(
            painter = painterResource(id = weatherIconRes),
            contentDescription = null,
            modifier = Modifier.size(120.dp)
        )

        Text(
            "${current?.temperature_2m?.toInt()}°C",
            style = MaterialTheme.typography.displayLarge,
            color = textColor
        )
        Spacer(Modifier.height(8.dp))

        Text(
            weatherCodeToText(current?.weather_code),
            style = MaterialTheme.typography.headlineSmall,
            color = textColor
        )

        Spacer(Modifier.height(8.dp))
        Text(
            "Feels like: ${current?.apparent_temperature?.toInt()}°C",
            style = MaterialTheme.typography.titleMedium,
            color = textAlphaColor
        )

        Spacer(Modifier.height(24.dp))

        // New Row for additional weather details with light boxes
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Wind Speed
            WeatherDetailItem(
                label = "Wind",
                value = "${current?.wind_speed_10m?.toInt()} km/h",
                iconRes = R.drawable.ic_wind,
                textColor = textColor,
                boxBackgroundColor = boxBackgroundColor
            )

            // Humidity
            WeatherDetailItem(
                label = "Humidity",
                value = "${current?.relative_humidity_2m?.toInt()}%",
                iconRes = R.drawable.ic_humidity,
                textColor = textColor,
                boxBackgroundColor = boxBackgroundColor
            )

            // Precipitation
            WeatherDetailItem(
                label = "Precipitation",
                value = "${current?.precipitation} mm",
                iconRes = R.drawable.ic_rain,
                textColor = textColor,
                boxBackgroundColor = boxBackgroundColor
            )
        }
    }

    Spacer(Modifier.height(32.dp))

    Text(
        "Next 7 Days",
        style = MaterialTheme.typography.titleLarge,
        color = textColor,
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(16.dp))

    LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        val days = (daily?.time ?: emptyList())
        items(days) { dateString ->
            val i = days.indexOf(dateString)
            val max = daily?.temperature_2m_max?.getOrNull(i)?.toInt()
            val min = daily?.temperature_2m_min?.getOrNull(i)?.toInt()
            val code = daily?.weather_code?.getOrNull(i)
            val isDayForecast = current?.is_day == 1

            val dayOfWeek = getDayOfWeek(dateString)

            ElevatedCard(
                modifier = Modifier
                    .width(120.dp)
                    .clip(RoundedCornerShape(12.dp)),
                colors = CardDefaults.elevatedCardColors(
//                    containerColor = textColor.copy(alpha = 0.2f)
                    containerColor = boxBackgroundColor
                ),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (i == 0) "TODAY" else dayOfWeek.uppercase(Locale.getDefault()),
                        color = textColor,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(12.dp))
                    Image(
                        painter = painterResource(id = weatherCodeToIcon(code, isDayForecast)),
                        contentDescription = null,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "${min}° / ${max}°",
                        style = MaterialTheme.typography.titleMedium,
                        color = textColor
                    )
                }
            }
        }
    }
    // Spacer at the bottom for better visual spacing when scrolled to the end
    Spacer(Modifier.height(64.dp))
}

@Composable
fun WeatherDetailItem(
    label: String,
    value: String,
    iconRes: Int,
    textColor: Color,
    boxBackgroundColor: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(boxBackgroundColor)
            .padding(12.dp)
    ) {
        Image(
            painter = painterResource(id = iconRes),
            contentDescription = null,
            modifier = Modifier.size(32.dp)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
            color = textColor
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = textColor.copy(alpha = 0.8f)
        )
    }
}


// Helper function for API levels below 26
private fun getDayOfWeek(dateString: String): String {
    val parser = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val formatter = SimpleDateFormat("EEE", Locale.getDefault())
    return try {
        val date = parser.parse(dateString)
        if (date != null) formatter.format(date) else ""
    } catch (e: Exception) {
        ""
    }
}