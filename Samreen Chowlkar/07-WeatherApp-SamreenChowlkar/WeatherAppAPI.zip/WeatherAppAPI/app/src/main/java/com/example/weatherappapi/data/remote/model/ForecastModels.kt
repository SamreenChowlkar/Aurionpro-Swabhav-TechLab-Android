package com.example.weatherappapi.data.remote.model

data class ForecastResponse(
    val latitude: Double,
    val longitude: Double,
    val timezone: String?,
    val current: CurrentWeather?,
    val daily: DailyWeather?
)

data class CurrentWeather(
    val time: String?,
    val temperature_2m: Double?,
    val relative_humidity_2m: Double?,
    val apparent_temperature: Double?,
    val is_day: Int?,
    val precipitation: Double?,
    val weather_code: Int?,
    val wind_speed_10m: Double?
)

data class DailyWeather(
    val time: List<String>?,
    val weather_code: List<Int>?,
    val temperature_2m_max: List<Double>?,
    val temperature_2m_min: List<Double>?
)
