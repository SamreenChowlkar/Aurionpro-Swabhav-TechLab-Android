package com.example.samreentasklogger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.collect
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.delay
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val database = TaskDatabase.getDatabase(this)
            val repository = TaskRepository(database.taskDao())
            val viewModel: TaskViewModel = viewModel(factory = TaskViewModelFactory(repository))
            TaskLoggerApp(viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskLoggerApp(viewModel: TaskViewModel) {
    val tasks by viewModel.allTasks.observeAsState(initial = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }

    // Logic to find the task with the smallest absolute time difference from now
    val nextTask = remember(tasks) {
        val currentTimeMillis = System.currentTimeMillis()
        tasks.minByOrNull {
            try {
                val taskTime = SimpleDateFormat("HH:mm", Locale.getDefault()).parse(it.dueTime)
                val calendar = Calendar.getInstance()
                calendar.set(Calendar.HOUR_OF_DAY, taskTime.hours)
                calendar.set(Calendar.MINUTE, taskTime.minutes)
                abs(calendar.timeInMillis - currentTimeMillis)
            } catch (e: Exception) {
                Long.MAX_VALUE // Treat parsing errors as a large difference
            }
        }
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "TASK LOGGER",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(Color.White)
                    .border(width = 1.dp, color = Color.Black),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "HOME",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(8.dp)
                )
                Text(
                    text = "CALENDER",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(8.dp)
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                shape = CircleShape,
                containerColor = Color.Black,
                modifier = Modifier.size(64.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Task",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            HeaderSection(nextTask)
            Spacer(modifier = Modifier.height(24.dp))
            TaskList(tasks = tasks, viewModel = viewModel, highlightedTask = nextTask)
        }
    }

    if (showAddDialog) {
        AddTaskDialog(
            onDismiss = { showAddDialog = false },
            onTaskAdded = { name, time ->
                viewModel.insert(Task(name = name, dueTime = time))
                showAddDialog = false
            }
        )
    }
}

@Composable
fun HeaderSection(nextTask: Task?) {
    val currentDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())

    val nextTaskName = nextTask?.name ?: "No upcoming tasks"

    var timeRemaining by remember { mutableStateOf("00:00:00") }

    // Coroutine to update the timer every second
    LaunchedEffect(nextTask) {
        if (nextTask != null) {
            while (true) {
                val currentTimeMillis = System.currentTimeMillis()
                val taskTime = SimpleDateFormat("HH:mm", Locale.getDefault()).parse(nextTask.dueTime)
                val calendar = Calendar.getInstance()
                calendar.set(Calendar.HOUR_OF_DAY, taskTime.hours)
                calendar.set(Calendar.MINUTE, taskTime.minutes)

                val timeDifferenceMillis = calendar.timeInMillis - currentTimeMillis

                if (timeDifferenceMillis > 0) {
                    val hours = TimeUnit.MILLISECONDS.toHours(timeDifferenceMillis)
                    val minutes = TimeUnit.MILLISECONDS.toMinutes(timeDifferenceMillis) % 60
                    val seconds = TimeUnit.MILLISECONDS.toSeconds(timeDifferenceMillis) % 60
                    timeRemaining = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                } else {
                    timeRemaining = "00:00:00"
                    break
                }
                delay(1000)
            }
        } else {
            timeRemaining = "00:00:00"
        }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = nextTaskName, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(text = timeRemaining, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "TODAY'S DATE",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = currentDate,
                    fontSize = 14.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun TaskList(tasks: List<Task>, viewModel: TaskViewModel, highlightedTask: Task?) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(tasks) { task ->
            // Check if the current task is the one that needs to be highlighted
            val isHighlighted = task == highlightedTask
            TaskItem(
                task = task,
                onDelete = { viewModel.delete(task) },
                isHighlighted = isHighlighted
            )
        }
    }
}

@Composable
fun TaskItem(task: Task, onDelete: (Task) -> Unit, isHighlighted: Boolean) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        // Change the background color based on the isHighlighted flag
        colors = CardDefaults.cardColors(containerColor = if (isHighlighted) Color(0xFFB3E5FC) else Color(0xFFF0F0F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Task name and time
                Text(
                    text = task.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.width(80.dp)
                )
                Spacer(modifier = Modifier.width(40.dp))
                Text(
                    text = task.dueTime,
                    fontSize = 14.sp
                )
            }
            Row {
                IconButton(onClick = { onDelete(task) }) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Task",
                        tint = Color.Red
                    )
                }

            }
        }
    }
}

@Composable
fun ActionButton(
    icon: ImageVector,
    contentDescription: String,
    color: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
        modifier = Modifier.size(40.dp),
        shape = RoundedCornerShape(8.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
        contentPadding = ButtonDefaults.ContentPadding
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = color,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
fun AddTaskDialog(onDismiss: () -> Unit, onTaskAdded: (String, String) -> Unit) {
    var taskName by remember { mutableStateOf("") }
    val hoursState = rememberLazyListState(initialFirstVisibleItemIndex = 0)
    val minutesState = rememberLazyListState(initialFirstVisibleItemIndex = 0)
    var selectedHour by remember { mutableStateOf(0) }
    var selectedMinute by remember { mutableStateOf(0) }

    // Use LaunchedEffect to observe the scroll state of the LazyColumns
    LaunchedEffect(hoursState) {
        snapshotFlow { hoursState.firstVisibleItemIndex }
            .collect { index ->
                selectedHour = index
            }
    }

    LaunchedEffect(minutesState) {
        snapshotFlow { minutesState.firstVisibleItemIndex }
            .collect { index ->
                selectedMinute = index
            }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Add New Task",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                TextField(
                    value = taskName,
                    onValueChange = { taskName = it },
                    label = { Text("Task Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Time Picker Section
                Text(
                    text = "Set Due Time",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Hours Picker
                    LazyColumn(
                        modifier = Modifier.height(100.dp).width(60.dp),
                        state = hoursState
                    ) {
                        items(24) { hour ->
                            val isSelected = hour == selectedHour
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .background(if (isSelected) Color.LightGray else Color.Transparent),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = String.format("%02d", hour),
                                    fontSize = if (isSelected) 24.sp else 18.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.Black else Color.Gray
                                )
                            }
                        }
                    }

                    Text(text = ":", fontSize = 24.sp, modifier = Modifier.padding(horizontal = 8.dp))

                    // Minutes Picker
                    LazyColumn(
                        modifier = Modifier.height(100.dp).width(60.dp),
                        state = minutesState
                    ) {
                        items(60) { minute ->
                            val isSelected = minute == selectedMinute
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .background(if (isSelected) Color.LightGray else Color.Transparent),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = String.format("%02d", minute),
                                    fontSize = if (isSelected) 24.sp else 18.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.Black else Color.Gray
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Button(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            if (taskName.isNotBlank()) {
                                val time = String.format("%02d:%02d", selectedHour, selectedMinute)
                                onTaskAdded(taskName, time)
                            }
                        },
                        enabled = taskName.isNotBlank()
                    ) {
                        Text("Add")
                    }
                }
            }
        }
    }
}
