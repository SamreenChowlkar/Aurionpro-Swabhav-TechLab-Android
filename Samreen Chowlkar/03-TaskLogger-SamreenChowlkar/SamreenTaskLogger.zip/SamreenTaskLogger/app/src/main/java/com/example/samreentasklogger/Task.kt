package com.example.samreentasklogger

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val dueTime: String,
    val isCompleted: Boolean = false
)
