package com.example.protocoldecoder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.protocoldecoder.ui.theme.ProtocolDecoderTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProtocolDecoderTheme {
                // A surface container using the 'background' color from the theme
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    ProtocolDecoderApp()
                }
            }
        }
    }
}
@Composable
fun ProtocolDecoderApp() {
    var input by remember { mutableStateOf(TextFieldValue("")) }
    var output by remember { mutableStateOf("") }
    var output1 by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Enter Hex Frame") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { input = TextFieldValue("7E 01 10 02 1A 2B 58 12 34 7E") },
                modifier = Modifier.weight(1f)
            ) { Text("Paste Example") }

            Button(
                onClick = {
                    input = TextFieldValue("")
                    output = ""
                    output1 = ""
                },
                modifier = Modifier.weight(1f)
            ) { Text("Clear All") }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val arr = input.text.trim().split(" ").filter { it.isNotBlank() }
                    if (arr.size >= 4) {
                        val deviceId = arr[1]
                        val command = arr[2]
                        val length = arr[3].toInt(16)
                        output = "DeviceID=0x$deviceId, Command=0x$command, Length=$length"
                        output1 = ""
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Parse Header") }

            Button(
                onClick = {
                    val arr = input.text.trim().split(" ").filter { it.isNotBlank() }
                    if (arr.size > 4) {
                        val length = arr[3].toInt(16)
                        val payload = arr.subList(4, 4 + length).joinToString(" ")
                        output = "Payload = $payload"
                        output1 = ""
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Show Payload") }
        }

        Button(
            onClick = {
                val arr = input.text.trim()
                    .replace(" ", "")
                    .chunked(2)
                    .map { it.uppercase() }

                if (arr.size > 7) {
                    val deviceId = arr[1].toInt(16)
                    val command = arr[2].toInt(16)
                    val length = arr[3].toInt(16)
                    val payload = arr.subList(4, 4 + length).map { it.toInt(16) }

                    // Checksum calculation
                    val calcChecksum = (deviceId + command + length + payload.sum()) and 0xFF
                    val givenChecksum = arr[4 + length].toInt(16)

                    // CRC16-CCITT calculation
                    fun crc16Ccitt(data: List<Int>): Int {
                        var crc = 0xFFFF
                        for (b in data) {
                            crc = crc xor (b shl 8)
                            repeat(8) {
                                crc = if ((crc and 0x8000) != 0) {
                                    ((crc shl 1) xor 0x1021) and 0xFFFF
                                } else {
                                    (crc shl 1) and 0xFFFF
                                }
                            }
                        }
                        return crc and 0xFFFF
                    }

                    val calcCrc = crc16Ccitt(listOf(deviceId, command, length) + payload)
                    val givenCrc = (arr[5 + length].toInt(16) shl 8) or arr[6 + length].toInt(16)

                    output =
                        "Checksum: given=0x${givenChecksum.toString(16)}, calc=0x${calcChecksum.toString(16)} -> " +
                                if (givenChecksum == calcChecksum) "VALID ✅" else "INVALID ❌"

                    output1 =
                        "CRC: given=0x${givenCrc.toString(16)}, calc=0x${calcCrc.toString(16)} -> " +
                                if (givenCrc == calcCrc) "VALID ✅" else "INVALID ❌"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Validate Frame") }

        ResultDisplay(output = output, output1 = output1)
    }
}

@Composable
fun ResultDisplay(output: String, output1: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (output.isNotEmpty()) {
                Text(
                    text = output,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = getStatusColor(output.contains("VALID"))
                )
            }
            if (output1.isNotEmpty()) {
                Text(
                    text = output1,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = getStatusColor(output1.contains("VALID"))
                )
            }
        }
    }
}

@Composable
fun getStatusColor(isValid: Boolean): Color {
    return if (isValid) Color.Green else Color.Red
}