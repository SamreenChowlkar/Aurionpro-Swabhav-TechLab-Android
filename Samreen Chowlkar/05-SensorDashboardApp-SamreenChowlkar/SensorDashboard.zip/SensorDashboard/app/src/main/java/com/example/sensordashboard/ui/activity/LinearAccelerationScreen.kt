package com.example.sensordashboard.ui.activity

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.absoluteValue
import kotlin.math.pow
import kotlin.math.sqrt

@Composable
fun LinearAccelerationScreen() {
    val context = LocalContext.current
    val sensorManager = remember { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val linearAccelSensor = remember { sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION) }

    var x by remember { mutableStateOf(0f) }
    var y by remember { mutableStateOf(0f) }
    var z by remember { mutableStateOf(0f) }
    var peakMagnitude by remember { mutableStateOf(0f) }

    val historyX = remember { mutableStateListOf<Float>() }
    val historyY = remember { mutableStateListOf<Float>() }
    val historyZ = remember { mutableStateListOf<Float>() }
    val listening = remember { mutableStateOf(true) }

    val listener = remember {
        object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (listening.value) {
                    x = event.values[0]
                    y = event.values[1]
                    z = event.values[2]

                    val currentMagnitude = sqrt(x.pow(2) + y.pow(2) + z.pow(2))
                    if (currentMagnitude > peakMagnitude) {
                        peakMagnitude = currentMagnitude
                    }

                    historyX.add(x)
                    historyY.add(y)
                    historyZ.add(z)

                    if (historyX.size > 50) historyX.removeAt(0)
                    if (historyY.size > 50) historyY.removeAt(0)
                    if (historyZ.size > 50) historyZ.removeAt(0)
                }
            }
            override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
        }
    }

    DisposableEffect(key1 = linearAccelSensor, key2 = listening.value) {
        if (linearAccelSensor != null && listening.value) {
            sensorManager.registerListener(listener, linearAccelSensor, SensorManager.SENSOR_DELAY_UI)
        } else if (!listening.value) {
            sensorManager.unregisterListener(listener)
        } else {
            Toast.makeText(context, "Linear Acceleration Sensor not available", Toast.LENGTH_SHORT).show()
        }
        onDispose { sensorManager.unregisterListener(listener) }
    }

    val animatedMagnitude by animateFloatAsState(targetValue = sqrt(x.pow(2) + y.pow(2) + z.pow(2)))

    val navy = Color(0xFF2C3E50)
    val lightNavy = Color(0xFF34495E)
    val beige = Color(0xFFF5F5F5)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(navy)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Linear Acceleration",
            style = MaterialTheme.typography.headlineSmall,
            color = beige,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(24.dp))

        // Live Values Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = lightNavy)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Current Readings",
                    color = beige.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    SensorValueText("X:", x, beige)
                    SensorValueText("Y:", y, beige)
                    SensorValueText("Z:", z, beige)
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Magnitude Gauge Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = beige)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Acceleration Magnitude",
                    color = navy,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Gauge visualization
                Box(
                    modifier = Modifier.size(150.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.matchParentSize()) {
                        drawArc(
                            color = Color.Gray.copy(alpha = 0.3f),
                            startAngle = 135f,
                            sweepAngle = 270f,
                            useCenter = false,
                            style = Stroke(width = 20f, cap = StrokeCap.Round)
                        )

                        drawArc(
                            color = navy,
                            startAngle = 135f,
                            sweepAngle = animatedMagnitude.coerceIn(0f, 20f) / 20f * 270f,
                            useCenter = false,
                            style = Stroke(width = 20f, cap = StrokeCap.Round)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "%.2f".format(animatedMagnitude),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = navy
                        )
                        Text(
                            text = "m/s²",
                            fontSize = 14.sp,
                            color = Color.Gray
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Peak: %.2f m/s²".format(peakMagnitude),
                    color = navy.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Real-time Graph Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = beige)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "Real-time Graph",
                    color = navy,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                ) {
                    val w = size.width
                    val h = size.height
                    val pointSpacing = if (historyX.size > 1) w / (historyX.size - 1) else 0f
                    val yRange = 20f
                    val yCenter = h / 2f

                    // Draw grid lines
                    val lineCount = 5
                    for (i in 0 until lineCount) {
                        val yPos = h / (lineCount - 1) * i
                        drawLine(
                            color = Color.Gray.copy(alpha = 0.5f),
                            start = Offset(0f, yPos),
                            end = Offset(w, yPos)
                        )
                    }

                    fun drawLineGraph(history: List<Float>, color: Color) {
                        if (history.isEmpty()) return
                        val path = Path()
                        val startY = yCenter - (history.firstOrNull() ?: 0f) * (h / yRange)
                        path.moveTo(0f, startY)
                        history.forEachIndexed { index, value ->
                            val xPos = index * pointSpacing
                            val yPos = yCenter - value * (h / yRange)
                            path.lineTo(xPos, yPos.coerceIn(0f, h))
                        }
                        drawPath(path, color, style = Stroke(width = 4f))
                    }

                    drawLineGraph(historyX, Color.Red)
                    drawLineGraph(historyY, Color.Green)
                    drawLineGraph(historyZ, Color.Blue)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    LabelDot(Color.Red, "X-axis")
                    LabelDot(Color.Green, "Y-axis")
                    LabelDot(Color.Blue, "Z-axis")
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Control buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = { listening.value = !listening.value },
                colors = ButtonDefaults.buttonColors(containerColor = lightNavy)
            ) {
                Text(if (listening.value) "Pause" else "Resume", color = beige)
            }
            Button(
                onClick = {
                    historyX.clear()
                    historyY.clear()
                    historyZ.clear()
                    x = 0f
                    y = 0f
                    z = 0f
                    peakMagnitude = 0f
                },
                colors = ButtonDefaults.buttonColors(containerColor = lightNavy)
            ) {
                Text("Reset", color = beige)
            }
        }
    }
}

@Composable
fun SensorValueText(label: String, value: Float, textColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = textColor.copy(alpha = 0.7f), fontSize = 16.sp)
        Text(
            "%.2f m/s²".format(value),
            color = textColor,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun LabelDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(modifier = Modifier.size(10.dp)) {
            drawCircle(color = color)
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, color = Color.Gray, fontSize = 12.sp)
    }
}