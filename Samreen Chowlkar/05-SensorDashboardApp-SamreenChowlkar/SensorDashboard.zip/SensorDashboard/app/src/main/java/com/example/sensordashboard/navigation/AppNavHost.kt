package com.example.sensordashboard.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.sensordashboard.ui.activity.AccelerometerDetailScreen
import com.example.sensordashboard.ui.activity.AmbientLightScreen
import com.example.sensordashboard.ui.activity.BarcodeScannerScreen
import com.example.sensordashboard.ui.activity.DashboardScreen
import com.example.sensordashboard.ui.activity.DeviceInfoScreen
import com.example.sensordashboard.ui.activity.GravitySensorScreen
import com.example.sensordashboard.ui.activity.GyroscopeDetailScreen
import com.example.sensordashboard.ui.activity.HomeDashboardScreen
import com.example.sensordashboard.ui.activity.LinearAccelerationScreen
import com.example.sensordashboard.ui.activity.MagnetometerScreen
import com.example.sensordashboard.ui.activity.ProximityScreen
import com.example.sensordashboard.ui.activity.QrScannerScreen
import com.example.sensordashboard.ui.activity.ScannerDashboard
import com.example.sensordashboard.ui.activity.SettingsScreen
import com.example.sensordashboard.ui.activity.StepCounterScreen
import com.example.sensordashboard.ui.activity.StepDetectorScreen

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Screen.HomeDashboard.route) {
        composable(Screen.Dashboard.route) { DashboardScreen(navController) }
        composable(Screen.HomeDashboard.route) { HomeDashboardScreen(navController) }
        composable(Screen.ScannerDashboard.route) { ScannerDashboard(navController) }
        composable(Screen.QrCodeScannerScreen.route) { QrScannerScreen(navController) }
        composable(Screen.BarcodeScannerScreen.route) { BarcodeScannerScreen(navController) } // Add a route in Screen.kt if needed
        composable(Screen.AccelerometerDetail.route) { AccelerometerDetailScreen() }
        composable(Screen.GyroscopeDetail.route) { GyroscopeDetailScreen() }
        composable(Screen.MagnetoMeter.route) { MagnetometerScreen() }
        composable(Screen.Proximity.route) { ProximityScreen() }
        composable(Screen.AmbientLight.route) { AmbientLightScreen() }
        composable(Screen.GravitySensor.route) { GravitySensorScreen() }
        composable(Screen.StepCounter.route) { StepCounterScreen() }
        composable(Screen.StepDetector.route) { StepDetectorScreen() }
        composable(Screen.LinearAcceleration.route) { LinearAccelerationScreen() }
        composable(Screen.DeviceInfo.route) { DeviceInfoScreen() }
        composable(Screen.Settings.route) { SettingsScreen(navController) }
    }
}

