package com.example.sensordashboard.ui.activity

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlin.math.max
import kotlin.math.min

@Composable
fun GravitySensorScreen() {
    val context = LocalContext.current
    val sensorManager = remember { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val gravitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)

    var gravityX by remember { mutableStateOf(0f) }
    var gravityY by remember { mutableStateOf(0f) }
    var gravityZ by remember { mutableStateOf(0f) }

    // Animate the platform rotation for a smooth visual effect
    val rotationX by animateFloatAsState(targetValue = -gravityY * 1.5f) // Reverse Y for intuitive tilt
    val rotationY by animateFloatAsState(targetValue = gravityX * 1.5f)  // Reverse X for intuitive tilt

    // Sensor Listener
    DisposableEffect(Unit) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                gravityX = event.values[0]
                gravityY = event.values[1]
                gravityZ = event.values[2]
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        if (gravitySensor != null) {
            sensorManager.registerListener(listener, gravitySensor, SensorManager.SENSOR_DELAY_GAME)
        }

        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF2C3E50) // Deep navy background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Gravity Sensor Demo",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(24.dp))

            // 3D Platform Simulation within a Card
            Card(
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFFF5F5F5)) // Soft beige background to match dashboard tiles
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // The creative visualization: a 3D-like platform with a rolling ball
                    Box(modifier = Modifier
                        .fillMaxSize(0.8f)
                        .graphicsLayer(
                            rotationX = rotationX,
                            rotationY = rotationY
                        )
                    ) {
                        // Background of the "platform"
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFFD3D3D3), RoundedCornerShape(12.dp))
                        )

                        // The "ball" rolling on the platform
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val ballRadius = 40f
                            val centerX = size.width / 2
                            val centerY = size.height / 2

                            // Scale gravity values to position the ball on the platform
                            val maxOffsetX = size.width / 2 - ballRadius
                            val maxOffsetY = size.height / 2 - ballRadius

                            val offsetX = min(max(gravityX * 30f, -maxOffsetX), maxOffsetX)
                            val offsetY = min(max(gravityY * 30f, -maxOffsetY), maxOffsetY)

                            val ballCenter = Offset(centerX - offsetX, centerY + offsetY)

                            drawCircle(
                                color = Color(0xFFE4A950), // Golden accent color
                                radius = ballRadius,
                                center = ballCenter
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Display raw values with white text
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = "X: %.2f".format(gravityX), color = Color.White.copy(alpha = 0.9f))
                Text(text = "Y: %.2f".format(gravityY), color = Color.White.copy(alpha = 0.9f))
                Text(text = "Z: %.2f".format(gravityZ), color = Color.White.copy(alpha = 0.9f))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tip for the user
            Text(
                "Tip: Tilt the device to see the platform respond to gravity, and watch the ball roll to the lowest point.",
                color = Color.LightGray,
                fontSize = 14.sp
            )
        }
    }
}
