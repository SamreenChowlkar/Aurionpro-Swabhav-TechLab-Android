package com.example.sensordashboard.ui.activity

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun StepCounterScreen() {
    val context = LocalContext.current

    // --- Runtime Permission ---
    var permissionGranted by remember { mutableStateOf(
        context.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED
    ) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted -> permissionGranted = granted }
    )

    LaunchedEffect(Unit) {
        if (!permissionGranted) launcher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
    }

    if (!permissionGranted) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF2C3E50)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Permission required to access step counter",
                color = Color(0xFFF5F5F5), // Beige text
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
        return
    }

    // --- Step Counter Logic ---
    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val stepSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

    var stepCount by remember { mutableStateOf(0) }
    val stepGoal = 5000

    DisposableEffect(Unit) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type == Sensor.TYPE_STEP_COUNTER) {
                    stepCount = event.values[0].toInt()
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        stepSensor?.let { sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) }
        onDispose { sensorManager.unregisterListener(listener) }
    }

    val progress = (stepCount.toFloat() / stepGoal).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(targetValue = progress)

    // --- UI ---
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF2C3E50) // Deep navy background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Title with a footprint icon
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "👣",
                    fontSize = 28.sp,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = "Step Counter",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Spacer(modifier = Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFFF5F5F5)), // Soft beige background
                    contentAlignment = Alignment.Center
                ) {
                    // Progress Ring
                    Box(modifier = Modifier.size(250.dp), contentAlignment = Alignment.Center) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Background ring
                            drawArc(
                                color = Color(0xFFE4A950).copy(alpha = 0.3f), // Light golden ring
                                startAngle = -90f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(width = 30f, cap = StrokeCap.Round)
                            )
                            // Progress ring
                            drawArc(
                                color = Color(0xFFE4A950), // Golden accent color
                                startAngle = -90f,
                                sweepAngle = 360f * animatedProgress,
                                useCenter = false,
                                style = Stroke(width = 30f, cap = StrokeCap.Round)
                            )
                        }
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                "$stepCount",
                                fontSize = 60.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2C3E50) // Dark navy text
                            )
                            Text(
                                "/ $stepGoal steps",
                                fontSize = 18.sp,
                                color = Color(0xFF2C3E50).copy(alpha = 0.8f) // Dark navy text
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))

            // Tips section
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Text("Tips:", color = Color.White)
                Text("• The step counter starts from a base value. The number may not be zero when you open the app.", color = Color.LightGray, fontSize = 14.sp)
                Text("• Walk around with your device to see the step count increase.", color = Color.LightGray, fontSize = 14.sp)
                Text("• The goal is set to 5000 steps, but you can change this value in the code.", color = Color.LightGray, fontSize = 14.sp)
            }
        }
    }
}
