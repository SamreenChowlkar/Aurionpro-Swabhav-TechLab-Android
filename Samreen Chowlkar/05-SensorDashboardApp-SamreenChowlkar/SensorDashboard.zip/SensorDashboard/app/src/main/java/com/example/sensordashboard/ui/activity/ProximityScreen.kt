package com.example.sensordashboard.ui.activity

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.text.style.TextAlign
import kotlin.math.roundToInt

// Color Palette
val NavyBlue = Color(0xFF2C3E50)
val DarkNavy = Color(0xFF34495E)
val Beige = Color(0xFFF5F5F5)
val Teal = Color(0xFF008080)
val BrickRed = Color(0xFFB22222)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProximityScreen() {
    val context = LocalContext.current
    val activity = context as? Activity

    // Sensor objects
    val sensorManager = remember { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val proximitySensor = remember { sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY) }

    // Camera / torch state
    var flashAvailable by remember { mutableStateOf(false) }
    var cameraId by remember { mutableStateOf<String?>(null) }

    // Proximity & UI state
    var isNear by remember { mutableStateOf(false) }
    var sensorPresent by remember { mutableStateOf(proximitySensor != null) }

    // Permission handling
    val hasCameraPermissionInitial = remember {
        ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }
    var cameraPermissionGranted by remember { mutableStateOf(hasCameraPermissionInitial) }
    val permissionLauncher = rememberLauncherForActivityResult(RequestPermission()) { granted ->
        cameraPermissionGranted = granted
        if (!granted) Toast.makeText(context, "Camera permission required to control torch", Toast.LENGTH_SHORT).show()
    }

    // Try to find camera id with flash once permission is available (or if permission is already granted)
    LaunchedEffect(cameraPermissionGranted) {
        if (!cameraPermissionGranted) {
            flashAvailable = false
            cameraId = null
        } else {
            try {
                val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                var found: String? = null
                for (id in cm.cameraIdList) {
                    val chars = cm.getCameraCharacteristics(id)
                    val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    // prefer back camera with flash
                    if (hasFlash) {
                        found = id
                        break
                    }
                }
                cameraId = found
                flashAvailable = found != null
            } catch (e: Exception) {
                flashAvailable = false
                cameraId = null
            }
        }
    }

    // Sensor listener registration (Composables + DisposableEffect)
    DisposableEffect(proximitySensor, cameraPermissionGranted, cameraId) {
        if (proximitySensor == null) {
            sensorPresent = false
            onDispose { /* nothing to unregister */ }
        } else {
            sensorPresent = true
            val listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent?) {
                    if (event == null) return
                    val near = event.values[0] < (proximitySensor.maximumRange)
                    isNear = near

                    if (cameraPermissionGranted && flashAvailable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            val camManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                            cameraId?.let { camManager.setTorchMode(it, near) }
                        } catch (ex: Exception) {
                            Toast.makeText(context, "Torch control failed: ${ex.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
            }
            sensorManager.registerListener(listener, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL)
            onDispose {
                sensorManager.unregisterListener(listener)
                if (cameraPermissionGranted && flashAvailable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    try {
                        val camManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                        cameraId?.let { camManager.setTorchMode(it, false) }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    // UI
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Proximity Sensor", color = Beige) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkNavy)
            )
        },
        containerColor = NavyBlue,
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Main Status Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .padding(vertical = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Beige)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isNear) BrickRed else Teal),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isNear) "NEAR" else "FAR",
                            fontSize = 60.sp,
                            fontWeight = FontWeight.Bold,
                            color = Beige
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = if (isNear) "Torch ON" else "Torch OFF",
                            fontSize = 24.sp,
                            color = Beige
                        )
                    }
                }
            }

            // Info Tiles
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                InfoTile(
                    title = "Sensor",
                    value = if (sensorPresent) "Present" else "Not Found",
                    icon = if (sensorPresent) Icons.Default.Settings else Icons.Default.Warning
                )
                InfoTile(
                    title = "Torch",
                    value = if (flashAvailable) "Available" else "N/A",
                    icon = Icons.Default.Info
                )
                InfoTile(
                    title = "Permission",
                    value = if (cameraPermissionGranted) "Granted" else "Missing",
                    icon = if (cameraPermissionGranted) Icons.Default.Info else Icons.Default.Warning
                )
            }

            Spacer(Modifier.height(32.dp))

            // Controls
            if (!cameraPermissionGranted) {
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkNavy)
                ) {
                    Text("Request Camera Permission", color = Beige)
                }
            } else {
                Text(
                    text = "Proximity sensor automatically controls the torch.",
                    color = Beige.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "Cover the top of your phone to turn the torch on.",
                    color = Beige.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.height(16.dp))

            Text(
                text = "Note: Emulator may not have a proximity sensor or flash. Test on a real device.",
                color = Beige.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun InfoTile(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        modifier = Modifier.width(100.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Beige)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = DarkNavy
            )
            Spacer(Modifier.height(4.dp))
            Text(title, color = DarkNavy, fontSize = 12.sp)
            Text(value, color = DarkNavy, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}