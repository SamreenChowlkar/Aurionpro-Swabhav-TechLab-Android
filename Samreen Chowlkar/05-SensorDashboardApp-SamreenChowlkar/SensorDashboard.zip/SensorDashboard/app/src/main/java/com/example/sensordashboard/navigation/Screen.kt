package com.example.sensordashboard.navigation

sealed class Screen(val route: String) {
    object Dashboard : Screen("dashboard")
    object AccelerometerDetail : Screen("accelerometer")
    object HomeDashboard : Screen("homeDashboard")
    object ScannerDashboard : Screen("ScannerDashboard")
    object QrCodeScannerScreen : Screen("QrCodeScannerScreen")
    object BarcodeScannerScreen : Screen("BarcodeScannerScreen")
    object GyroscopeDetail : Screen("gyroscope")
    object MagnetoMeter : Screen("magnetometer")
    object Proximity : Screen("proximity_screen")
    object AmbientLight : Screen("ambientLight")
    object GravitySensor : Screen("gravitySensor")
    object StepCounter : Screen("stepCounterScreen")
    object StepDetector : Screen("stepDetectorScreen")
    object LinearAcceleration : Screen("linearAccelerationScreen")
    object DeviceInfo : Screen("device_info")
    object Settings : Screen("settings")
}
