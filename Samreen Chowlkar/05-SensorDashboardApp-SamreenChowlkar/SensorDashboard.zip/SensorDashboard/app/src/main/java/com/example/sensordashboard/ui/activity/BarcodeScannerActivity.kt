package com.example.sensordashboard.ui.activity

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarcodeScannerScreen(navController: NavHostController) {
    val context = LocalContext.current
    val clipboardManager: androidx.compose.ui.platform.ClipboardManager = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val options = remember {
        GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                Barcode.FORMAT_ALL_FORMATS
            )
            .enableAutoZoom()
            .build()
    }

    val scanner = remember { GmsBarcodeScanning.getClient(context, options) }

    var rawValue by remember { mutableStateOf<String?>(null) }
    var format by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var showResultCard by remember { mutableStateOf(false) }

    // Start scanning immediately
    LaunchedEffect(Unit) {
        scanner.startScan()
            .addOnSuccessListener { barc ->
                rawValue = barc.rawValue
                format = barc.format.toBarcodeName()
                showResultCard = true
            }
            .addOnFailureListener { e ->
                error = e.localizedMessage ?: "Scan Failed."
                showResultCard = true
            }
            .addOnCanceledListener {
                error = "Scan cancelled"
                showResultCard = true
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Barcode Scanner",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineLarge
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF34495E))
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        content = { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF2C3E50))
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Scanning for Barcode...",
                    color = Color(0xFFB0BEC5),
                    style = MaterialTheme.typography.titleLarge
                )
            }
        }
    )

    // Pop-up result card
    if (showResultCard) {
        AlertDialog(
            onDismissRequest = {
                showResultCard = false
                navController.navigate("ScannerDashboard") {
                    popUpTo("ScannerDashboard") { inclusive = true }
                }
            },
            containerColor = Color(0xFFF5F5F5), // Light beige for the card
            title = {
                Text(
                    "Scan Result",
                    color = Color(0xFF2C3E50),
                    style = MaterialTheme.typography.headlineSmall
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (error != null) {
                        Text(
                            "Status: Error 😢",
                            color = Color(0xFFEF5350),
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Message: $error",
                            color = Color(0xFF2C3E50),
                            textAlign = TextAlign.Center
                        )
                    } else {
                        Text(
                            "Status: Success 🎉",
                            color = Color(0xFF4CAF50),
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = rawValue ?: "N/A",
                            onValueChange = {},
                            label = { Text("Scanned Value", color = Color(0xFF2C3E50)) },
                            readOnly = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF4CAF50),
                                unfocusedBorderColor = Color(0xFFB0BEC5),
                                focusedLabelColor = Color(0xFF4CAF50),
                                unfocusedLabelColor = Color(0xFFB0BEC5),
                                focusedTextColor = Color(0xFF2C3E50),
                                unfocusedTextColor = Color(0xFF2C3E50),
                                cursorColor = Color(0xFF4CAF50)
                            ),
                            trailingIcon = {
                                IconButton(onClick = {
                                    rawValue?.let {
                                        clipboardManager.setText(AnnotatedString(it))
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Copied to clipboard!")
                                        }
                                    }
                                }) {
                                    Icon(
                                        Icons.Default.ContentCopy,
                                        contentDescription = "Copy to clipboard",
                                        tint = Color(0xFF2C3E50)
                                    )
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "Format: ${format ?: "N/A"}",
                            color = Color(0xFF2C3E50)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResultCard = false
                        navController.navigate("ScannerDashboard") {
                            popUpTo("ScannerDashboard") { inclusive = true }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34495E))
                ) {
                    Text("OK", color = Color.White)
                }
            },
            modifier = Modifier.clip(RoundedCornerShape(16.dp))
        )
    }
}

// Extension function to show barcode format name
private fun Int.toBarcodeName(): String = when (this) {
    Barcode.FORMAT_CODE_128 -> "CODE 128"
    Barcode.FORMAT_CODE_39 -> "CODE 39"
    Barcode.FORMAT_CODE_93 -> "CODE 93"
    Barcode.FORMAT_CODABAR -> "CODABAR"
    Barcode.FORMAT_DATA_MATRIX -> "Data Matrix"
    Barcode.FORMAT_EAN_13 -> "EAN 13"
    Barcode.FORMAT_EAN_8 -> "EAN 8"
    Barcode.FORMAT_ITF -> "ITF"
    Barcode.FORMAT_QR_CODE -> "QR Code"
    Barcode.FORMAT_UPC_A -> "UPC A"
    Barcode.FORMAT_UPC_E -> "UPC E"
    Barcode.FORMAT_PDF417 -> "PDF 417"
    Barcode.FORMAT_AZTEC -> "Aztec"
    else -> "Unknown"
}