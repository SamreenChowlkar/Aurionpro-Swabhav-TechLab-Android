package com.example.sensordashboard.ui.activity

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LineWeight
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.SensorOccupied
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.sensordashboard.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerDashboard(navController: NavHostController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Scanner Dashboard",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineLarge
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF34495E))
            )
        },
        bottomBar = {
            BottomNavigationBar(navController = navController)
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFF2C3E50)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(32.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ScannerTile(
                    modifier = Modifier.weight(1f),
                    title = "QR Scanner",
                    icon = {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "QR Scanner Icon",
                            tint = Color(0xFF2C3E50),
                            modifier = Modifier.size(48.dp)
                        )
                    },
                    onClick = { navController.navigate(Screen.QrCodeScannerScreen.route) }
                )
                ScannerTile(
                    modifier = Modifier.weight(1f),
                    title = "Barcode Scanner",
                    icon = {
                        Icon(
                            imageVector = Icons.Default.LineWeight,
                            contentDescription = "Barcode Scanner Icon",
                            tint = Color(0xFF2C3E50),
                            modifier = Modifier.size(48.dp)
                        )
                    },
                    onClick = { navController.navigate(Screen.BarcodeScannerScreen.route) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Status Card
            Card(
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF5F5F5))
                        .padding(24.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.SensorOccupied,
                            contentDescription = "Status Icon",
                            tint = Color(0xFF2C3E50),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "Status: Scanner Ready",
                            style = MaterialTheme.typography.titleLarge,
                            fontSize = 20.sp,
                            color = Color(0xFF2C3E50)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ScannerTile(
    modifier: Modifier = Modifier,
    title: String,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = modifier
            .height(180.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF5F5F5)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            icon()
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontSize = 22.sp,
                color = Color(0xFF2C3E50)
            )
        }
    }
}