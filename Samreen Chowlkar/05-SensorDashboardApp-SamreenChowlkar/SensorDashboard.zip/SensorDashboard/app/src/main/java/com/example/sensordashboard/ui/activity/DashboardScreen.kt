package com.example.sensordashboard.ui.activity

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.sensordashboard.navigation.Screen
import com.example.sensordashboard.components.SensorCard

// Data class to hold sensor information, including its icon and category
data class SensorItem(
    val name: String,
    val icon: ImageVector,
    val category: String,
    val route: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavHostController) {
    // Define your sensor data with icons and categories
    val allSensors = listOf(
        // Motion
        SensorItem("Accelerometer", Icons.Default.DirectionsRun, "Motion", Screen.AccelerometerDetail.route),
        SensorItem("Gyroscope", Icons.Default.RotateRight, "Motion", Screen.GyroscopeDetail.route),
        SensorItem("Gravity", Icons.Default.VerticalAlignBottom, "Motion", Screen.GravitySensor.route),
        SensorItem("Step Counter", Icons.Default.FitnessCenter, "Motion", Screen.StepCounter.route),
        SensorItem("Step Detector", Icons.Default.DirectionsWalk, "Motion", Screen.StepDetector.route),

        // Position
        SensorItem("Magnetometer", Icons.Default.Explore, "Position", Screen.MagnetoMeter.route),
        SensorItem("Linear Accel", Icons.Default.Speed, "Position", Screen.LinearAcceleration.route),

        // Environment
        SensorItem("Ambient Light", Icons.Default.LightMode, "Environment", Screen.AmbientLight.route),
        SensorItem("Proximity", Icons.Default.SensorOccupied, "Environment", Screen.Proximity.route),
    )

    // Group sensors by their category
    val sensorCategories = allSensors.groupBy { it.category }
    val categories = sensorCategories.keys.toList()

    // State to keep track of the selected category
    var selectedCategory by remember { mutableStateOf(categories.first()) }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Sensor Dashboard",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF34495E))
            )
        },
        bottomBar = {
            BottomNavigationBar(navController = navController)
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFF2C3E50))
        ) {
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory),
                modifier = Modifier.fillMaxWidth(),
                containerColor = Color.Transparent,
                edgePadding = 0.dp
            ) {
                categories.forEach { category ->
                    Tab(
                        selected = category == selectedCategory,
                        onClick = { selectedCategory = category },
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Text(
                            text = category,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (category == selectedCategory) Color.White else Color.White.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            AnimatedVisibility(
                visible = true,
                enter = expandVertically(animationSpec = tween(durationMillis = 300)),
                exit = shrinkVertically(animationSpec = tween(durationMillis = 300))
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val sensorsForCategory = sensorCategories.getValue(selectedCategory)
                    items(sensorsForCategory) { sensor ->
                        SensorCardWithSolidColor(
                            sensor = sensor,
                            onClick = {
                                navController.navigate(sensor.route)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SensorCardWithSolidColor(sensor: SensorItem, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF5F5F5))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Icon(
                    imageVector = sensor.icon,
                    contentDescription = sensor.name,
                    tint = Color(0xFF2C3E50),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = sensor.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2C3E50)
                    ),
                    fontSize = 18.sp
                )
            }
        }
    }
}