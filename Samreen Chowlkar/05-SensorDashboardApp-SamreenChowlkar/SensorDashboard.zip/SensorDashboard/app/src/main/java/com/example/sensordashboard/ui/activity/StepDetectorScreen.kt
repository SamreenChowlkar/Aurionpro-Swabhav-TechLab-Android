package com.example.sensordashboard.ui.activity

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun StepDetectorScreen() {
    val context = LocalContext.current

    // --- Define the custom color palette ---
    val navyBackground = Color(0xFF2C3E50)
    val lightNavy = Color(0xFF34495E)
    val softBeige = Color(0xFFF5F5F5)
    val darkNavyText = Color(0xFF2C3E50)
    // Using a bright teal as the accent color for the pulse
    val tealAccent = Color(0xFF1ABC9C)

    // --- Sensor Manager & Step Detector Logic ---
    val sensorManager = remember { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val stepDetector = remember { sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) }

    var stepsDetected by remember { mutableStateOf(0) }
    var pulseTrigger by remember { mutableStateOf(false) }

    val listener = remember {
        object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type == Sensor.TYPE_STEP_DETECTOR) {
                    // A step has been detected. Increment the counter and trigger the animation.
                    stepsDetected++
                    pulseTrigger = true
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
                // Not used for this sensor type, but required to be implemented.
            }
        }
    }

    DisposableEffect(Unit) {
        // Register the sensor listener when the composable enters the composition.
        stepDetector?.let { sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) }
        // Unregister the listener when the composable is disposed to prevent memory leaks.
        onDispose { sensorManager.unregisterListener(listener) }
    }

    // --- Pulse Animation ---
    // Using a LaunchedEffect to manage the pulse state, triggering a short animation.
    val animatedProgress = remember { Animatable(0f) }

    LaunchedEffect(pulseTrigger) {
        if (pulseTrigger) {
            // Animate from 0 to 1, then reset the trigger.
            animatedProgress.animateTo(1f, animationSpec = tween(durationMillis = 300))
            animatedProgress.animateTo(0f, animationSpec = tween(durationMillis = 300))
            pulseTrigger = false
        }
    }

    // --- UI Layout ---
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(navyBackground), // Main background color
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth(0.8f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = softBeige), // Card background color
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "Step Detector",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = darkNavyText // Text color on the card
                )
                Spacer(modifier = Modifier.height(20.dp))

                // The pulsing circle and steps count display
                Box(
                    modifier = Modifier.size(160.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Inactive background circle
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = darkNavyText,
                            radius = size.minDimension / 3.2f,
                            style = Stroke(width = 4.dp.toPx())
                        )
                    }

                    // Pulsing animated circle on top
                    if (animatedProgress.value > 0f) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val radius = (size.minDimension / 3.2f) * (1f + animatedProgress.value * 0.2f)
                            drawCircle(
                                color = tealAccent.copy(alpha = animatedProgress.value),
                                radius = radius,
                                style = Stroke(width = 8.dp.toPx() * (1 - animatedProgress.value))
                            )
                        }
                    }

                    // Steps count text
                    Text(
                        text = "$stepsDetected",
                        fontSize = 48.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = darkNavyText
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    "Steps Detected",
                    fontSize = 20.sp,
                    color = darkNavyText
                )
            }
        }
    }
}
