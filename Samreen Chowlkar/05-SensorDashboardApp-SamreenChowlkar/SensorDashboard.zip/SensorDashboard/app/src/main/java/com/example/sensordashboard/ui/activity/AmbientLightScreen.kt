package com.example.sensordashboard.ui.activity

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.min

@Composable
fun AmbientLightScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var lightValue by remember { mutableStateOf(0f) }
    var isDarkTheme by remember { mutableStateOf(false) }

    val sensorManager = remember {
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }

    val lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)

    // Sensor Listener
    DisposableEffect(lifecycleOwner) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    lightValue = it.values[0] // lux
                    // Switch theme based on lux
                    isDarkTheme = lightValue < 40f // adjust threshold
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    sensorManager.registerListener(listener, lightSensor, SensorManager.SENSOR_DELAY_NORMAL)
                }
                Lifecycle.Event.ON_PAUSE -> {
                    sensorManager.unregisterListener(listener)
                }
                else -> {}
            }
        }

        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            sensorManager.unregisterListener(listener)
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Custom Color Palette for the Dashboard
    val backgroundColor = Color(0xFF2C3E50) // Deep Navy
    val cardColor = Color(0xFFF5F5F5) // Soft Beige
    val contentColor = Color(0xFF2C3E50) // Dark Navy for text/icons on cards

    // UI
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = backgroundColor
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .clip(RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = cardColor)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Ambient Light Sensor",
                        style = MaterialTheme.typography.titleLarge,
                        color = contentColor
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        "Current Lux: ${"%.2f".format(lightValue)} lx",
                        style = MaterialTheme.typography.titleLarge,
                        color = contentColor
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Dynamically colored progress bar
                    val progressColor by animateColorAsState(
                        targetValue = if (isDarkTheme) Color(0xFF34495E) else Color(0xFFF39C12),
                        animationSpec = tween(durationMillis = 500), label = "progressColorAnimation"
                    )

                    LinearProgressIndicator(
                        progress = min(lightValue / 1000f, 1f), // Corrected: passing a Float value
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        color = progressColor,
                        trackColor = contentColor.copy(alpha = 0.2f)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    val themeText = if (isDarkTheme) "Night Mode" else "Day Mode"
                    val icon = if (isDarkTheme) "🌙" else "☀️"

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$icon",
                            style = MaterialTheme.typography.headlineSmall,
                            color = contentColor
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = themeText,
                            style = MaterialTheme.typography.bodyLarge,
                            color = contentColor
                        )
                    }
                }
            }
        }
    }
}