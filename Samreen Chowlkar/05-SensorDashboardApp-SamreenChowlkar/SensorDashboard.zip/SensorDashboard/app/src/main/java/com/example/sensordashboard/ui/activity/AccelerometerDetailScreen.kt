package com.example.sensordashboard.ui.activity

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.abs

@SuppressLint("UnrememberedMutableState")
@Composable
fun AccelerometerDetailScreen() {
    val context = LocalContext.current
    val sensorManager = remember { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val accelerometer = remember { sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) }

    var x by remember { mutableStateOf(0f) }
    var y by remember { mutableStateOf(0f) }
    var z by remember { mutableStateOf(0f) }

    var listening by remember { mutableStateOf(true) }
    var lastShakeTime by remember { mutableStateOf(0L) }
    val shakeThreshold = 15f

    // Determine the device's orientation based on Z-axis acceleration
    val orientationMessage by derivedStateOf {
        when {
            z > 9f -> "Device facing up"
            z < -9f -> "Device facing down"
            else -> "On its side"
        }
    }

    // Map accelerometer values to bubble position, constraining the movement
    val bubbleOffsetX by derivedStateOf { (x / 12f).coerceIn(-1f, 1f) }
    val bubbleOffsetY by derivedStateOf { (y / 12f).coerceIn(-1f, 1f) }

    // Animate the bubble's position for smooth movement
    val animatedOffsetX by animateFloatAsState(targetValue = bubbleOffsetX)
    val animatedOffsetY by animateFloatAsState(targetValue = bubbleOffsetY)

    // Sensor event listener to update state variables
    val listener = remember {
        object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                x = event.values[0]
                y = event.values[1]
                z = event.values[2]

                // Shake detection logic
                val magnitude = abs(x) + abs(y) + abs(z)
                val now = System.currentTimeMillis()
                if (magnitude > shakeThreshold && now - lastShakeTime > 700) {
                    lastShakeTime = now
                    Toast.makeText(context, "Shake Detected!", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
        }
    }

    // Register and unregister the sensor listener
    DisposableEffect(key1 = listening) {
        if (accelerometer != null && listening) {
            sensorManager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { sensorManager.unregisterListener(listener) }
    }

    // Main UI layout
    Surface(
        modifier = Modifier.fillMaxSize(),
        // Matches the deep navy background of the dashboard
        color = Color(0xFF2C3E50)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Main title
            Text(
                "Accelerometer",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White // White text for visibility on dark background
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Display current sensor values
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("X: ${"%.2f".format(x)}", color = Color.White.copy(alpha = 0.9f))
                Text("Y: ${"%.2f".format(y)}", color = Color.White.copy(alpha = 0.9f))
                Text("Z: ${"%.2f".format(z)}", color = Color.White.copy(alpha = 0.9f))
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                orientationMessage,
                color = Color.White.copy(alpha = 0.6f) // Faded text for secondary info
            )

            Spacer(modifier = Modifier.height(24.dp))

            // The main visualization card
            Card(
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFFF5F5F5)) // Soft beige background to match dashboard tiles
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Static center dot
                    Box(modifier = Modifier
                        .size(32.dp)
                        .align(Alignment.Center)
                        .background(Color(0xFFD3D3D3), shape = RoundedCornerShape(16.dp)))

                    // The dynamic moving bubble
                    Box(modifier = Modifier
                        .size(50.dp)
                        .offset(x = (animatedOffsetX * 80).dp, y = (animatedOffsetY * -80).dp)
                        .align(Alignment.Center)
                        .background(Color(0xFFE4A950), shape = RoundedCornerShape(25.dp))) // Striking golden color
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Buttons row
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = { x = 0f; y = 0f; z = 0f },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF34495E), // Lighter navy button color
                        contentColor = Color.White
                    ),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text("Reset")
                }
                Spacer(modifier = Modifier.width(16.dp))
                Button(
                    onClick = { listening = !listening },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF34495E),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text(if (listening) "Pause" else "Resume")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Tips section
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Text("Tips:", color = Color.White)
                Text("• Shake the device to see shake detection (shows toast).", color = Color.LightGray)
                Text("• Use Reset to zero values. Toggle Pause to stop updates.", color = Color.LightGray)
            }
        }
    }
}
