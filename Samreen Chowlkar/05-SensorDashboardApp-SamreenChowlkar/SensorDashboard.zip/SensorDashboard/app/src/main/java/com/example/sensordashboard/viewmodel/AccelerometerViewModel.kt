package com.example.sensordashboard.viewmodel


import android.app.Application
import android.content.Context
import android.hardware.*
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class AccelerometerViewModel(app: Application) : AndroidViewModel(app), SensorEventListener {
    private val sensorManager = app.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val _x = MutableStateFlow(0f)
    private val _y = MutableStateFlow(0f)
    private val _z = MutableStateFlow(0f)
    val x = _x.asStateFlow()
    val y = _y.asStateFlow()
    val z = _z.asStateFlow()

    private val _running = MutableStateFlow(true)
    val running = _running.asStateFlow()

    init { sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI) }

    fun toggle() {
        if (_running.value) sensorManager.unregisterListener(this)
        else sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        _running.value = !_running.value
    }

    fun reset() {
        _x.value = 0f; _y.value = 0f; _z.value = 0f
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (_running.value) {
            _x.value = event.values[0]
            _y.value = event.values[1]
            _z.value = event.values[2]
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
