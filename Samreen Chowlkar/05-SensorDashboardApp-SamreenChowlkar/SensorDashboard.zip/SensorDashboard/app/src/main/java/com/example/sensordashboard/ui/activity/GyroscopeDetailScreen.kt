package com.example.sensordashboard.ui.activity

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun GyroscopeDetailScreen() {
    val context = LocalContext.current
    val sensorManager = remember { context.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val gyroscope = remember { sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) }

    var x by remember { mutableStateOf(0f) }
    var y by remember { mutableStateOf(0f) }
    var z by remember { mutableStateOf(0f) }
    var listening by remember { mutableStateOf(true) }

    // Animate the rotation values for a smooth visual effect.
    val rotationX by animateFloatAsState(targetValue = -y * 30f)
    val rotationY by animateFloatAsState(targetValue = x * 30f)
    val rotationZ by animateFloatAsState(targetValue = z * -30f) // Changed to negative to reverse rotation

    // Sensor event listener to update state variables with gyroscope data
    val listener = remember {
        object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                x = event.values[0]
                y = event.values[1]
                z = event.values[2]
            }
            override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
        }
    }

    // Register and unregister the sensor listener
    DisposableEffect(key1 = listening) {
        if (gyroscope != null && listening) {
            sensorManager.registerListener(listener, gyroscope, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { sensorManager.unregisterListener(listener) }
    }

    // Main UI layout
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF2C3E50) // Deep navy background
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Main title
            Text(
                "Gyroscope",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Display current sensor values
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("X: ${"%.2f".format(x)}", color = Color.White.copy(alpha = 0.9f))
                Text("Y: ${"%.2f".format(y)}", color = Color.White.copy(alpha = 0.9f))
                Text("Z: ${"%.2f".format(z)}", color = Color.White.copy(alpha = 0.9f))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // The main visualization card
            Card(
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFFF5F5F5)) // Soft beige background
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Main circle for X and Y rotation
                    Box(modifier = Modifier
                        .size(200.dp)
                        .graphicsLayer(
                            rotationX = rotationX,
                            rotationY = rotationY,
                        )
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(
                                color = Color(0xFFE4A950),
                                radius = size.minDimension / 2,
                                style = Stroke(width = 5f)
                            )
                        }

                        // Inner circle for Z rotation
                        Box(modifier = Modifier
                            .size(100.dp)
                            .align(Alignment.Center)
                            .rotate(rotationZ)
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawCircle(
                                    color = Color(0xFF2C3E50),
                                    radius = size.minDimension / 2,
                                    style = Stroke(width = 5f)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Buttons row
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = { x = 0f; y = 0f; z = 0f },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF34495E),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text("Reset")
                }
                Spacer(modifier = Modifier.width(16.dp))
                Button(
                    onClick = { listening = !listening },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF34495E),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text(if (listening) "Pause" else "Resume")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Tips section
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Text("Tips:", color = Color.White)
                Text("• The outer circle rotates as you tilt the device left/right (Y-axis) and forward/backward (X-axis).", color = Color.LightGray)
                Text("• The inner circle rotates as you twist the device (Z-axis).", color = Color.LightGray)
            }
        }
    }
}
