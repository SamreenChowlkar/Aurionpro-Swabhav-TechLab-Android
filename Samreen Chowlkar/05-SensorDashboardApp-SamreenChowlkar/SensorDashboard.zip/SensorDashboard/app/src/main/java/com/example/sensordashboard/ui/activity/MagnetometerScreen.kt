package com.example.sensordashboard.ui.activity

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.atan2
import kotlin.math.sqrt
import androidx.compose.ui.graphics.nativeCanvas
import android.graphics.Paint
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.sp
import android.widget.Toast

@Composable
fun MagnetometerScreen() {
    val context = LocalContext.current
    val sensorManager = remember {
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }

    var azimuth by remember { mutableStateOf(0f) }
    var fieldStrength by remember { mutableStateOf(0f) }
    var metalDetected by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                event?.let {
                    val x = it.values[0]
                    val y = it.values[1]
                    val z = it.values[2]

                    azimuth = (Math.toDegrees(atan2(y.toDouble(), x.toDouble())) + 360).toFloat() % 360
                    fieldStrength = sqrt(x * x + y * y + z * z)
                    metalDetected = fieldStrength > 80
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        val magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        sensorManager.registerListener(listener, magnetometer, SensorManager.SENSOR_DELAY_UI)

        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    val backgroundColor = Color(0xFF2C3E50)
    val cardColor = Color(0xFFF5F5F5)
    val textColor = Color(0xFF2C3E50)
    val circleColor = Color(0xFF2196F3)
    val needleColor = Color(0xFFE74C3C)

    val density = LocalDensity.current

    // Paint object for North
    val northTextPaint = Paint().apply {
        color = android.graphics.Color.BLACK
        textAlign = Paint.Align.CENTER
        textSize = with(density) { 35.sp.toPx() } // Larger size for "N"
        isFakeBoldText = true // Optional: make it bold
    }

    // Paint object for other directions
    val textPaint = Paint().apply {
        color = android.graphics.Color.BLACK
        textAlign = Paint.Align.CENTER
        textSize = with(density) { 28.sp.toPx() } // Standard size
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(cardColor)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Magnetometer",
                style = MaterialTheme.typography.headlineMedium,
                color = textColor,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(32.dp))

            Box(
                modifier = Modifier
                    .size(250.dp)
                    .background(Color.Transparent),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2, size.height / 2)
                    val radius = size.minDimension / 2 - 16.dp.toPx()

                    drawCircle(
                        color = circleColor.copy(alpha = 0.5f),
                        radius = radius,
                        style = Stroke(width = 4.dp.toPx()),
                        center = center
                    )

                    drawContext.canvas.nativeCanvas.apply {
                        val textRadius = radius + with(density) { 15.dp.toPx() }
                        save()
                        translate(center.x, center.y)

                        // N (North) with the larger paint object
                        rotate(-azimuth)
                        drawText("N", 0f, -textRadius, northTextPaint)
                        rotate(azimuth)

                        // E (East)
                        rotate(-azimuth)
                        drawText("E", textRadius, 0f, textPaint)
                        rotate(azimuth)

                        // S (South)
                        rotate(-azimuth)
                        drawText("S", 0f, textRadius, textPaint)
                        rotate(azimuth)

                        // W (West)
                        rotate(-azimuth)
                        drawText("W", -textRadius, 0f, textPaint)
                        rotate(azimuth)

                        restore()
                    }

                    rotate(-azimuth, pivot = center) {
                        drawLine(
                            color = needleColor,
                            start = center,
                            end = Offset(center.x, 50f),
                            strokeWidth = 10f
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 12.dp.toPx(),
                            center = center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Direction: ${azimuth.toInt()}°",
                style = MaterialTheme.typography.titleLarge,
                color = textColor
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Field Strength: ${"%.2f".format(fieldStrength)} µT",
                style = MaterialTheme.typography.titleMedium,
                color = textColor
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (metalDetected) {
                Text(
                    text = "⚠ Metal Nearby!",
                    color = Color.Red,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge
                )
            }
        }
    }
}