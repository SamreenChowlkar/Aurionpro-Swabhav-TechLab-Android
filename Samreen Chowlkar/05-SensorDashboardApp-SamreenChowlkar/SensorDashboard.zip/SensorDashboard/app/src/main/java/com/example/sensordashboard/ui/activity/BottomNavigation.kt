package com.example.sensordashboard.ui.activity

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.example.sensordashboard.navigation.Screen

@Composable
fun BottomNavigationBar(navController: NavController) {
    val context = LocalContext.current
    NavigationBar(
        containerColor = Color(0xFF607D8B),
        contentColor = Color.White
    ) {
        NavigationBarItem(
            icon = { Icon(Icons.Filled.Home, contentDescription = "Home", tint = Color.White) },
            label = { Text("Home", color = Color.White) },
            selected = false,
            onClick = { navController.navigate(Screen.HomeDashboard.route) }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Filled.Sensors, contentDescription = "Sensors", tint = Color.White) },
            label = { Text("Sensors", color = Color.White) },
            selected = false,
            onClick = { navController.navigate(Screen.Dashboard.route) }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Filled.QrCode, contentDescription = "QR", tint = Color.White) },
            label = { Text("QR", color = Color.White) },
            selected = false,
            onClick = { navController.navigate(Screen.ScannerDashboard.route) }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = Color.White) },
            label = { Text("Settings", color = Color.White) },
            selected = false,
            onClick = { navController.navigate(Screen.Settings.route) }
        )
    }
}